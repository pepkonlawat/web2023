// nochange.js
//   This script illustrates using the focus event
//   to prevent the user from changing a text field

// The event handler function to compute the cost

function computeCost() {
//add your code here
 var french = document.getElementById("french").value;

// Compute the cost
  totalCost = french 
  document.getElementById("cost").value = totalCost
  
}  //* end of computeCost

// load.js
//   An example to illustrate the load event

// The onload event handler

function load_greeting() {
    alert('Good morning');
}
